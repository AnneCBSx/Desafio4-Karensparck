﻿using System;
using System.Collections.Generic;
using WoMakersCode.Biblioteca.Core.Entities;

namespace WoMakersCode.Biblioteca.Core.Repositories
{
    public interface IAutorRepository : IRepository<Autor>
    {
    }
}
