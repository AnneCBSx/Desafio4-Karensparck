﻿using WoMakersCode.Biblioteca.Core.Entities;

namespace WoMakersCode.Biblioteca.Core.Repositories
{
    public interface ILivroRepository : IRepository<Livro>
    {
    }
}
