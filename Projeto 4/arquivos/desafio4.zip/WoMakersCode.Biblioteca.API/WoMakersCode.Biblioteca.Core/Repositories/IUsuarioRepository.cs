﻿using WoMakersCode.Biblioteca.Core.Entities;

namespace WoMakersCode.Biblioteca.Core.Repositories
{
    public interface IUsuarioRepository : IRepository<Usuario>
    {
    }
}
