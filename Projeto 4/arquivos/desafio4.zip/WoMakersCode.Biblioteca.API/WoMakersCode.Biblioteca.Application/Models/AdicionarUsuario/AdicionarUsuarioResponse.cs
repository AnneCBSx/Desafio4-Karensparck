﻿namespace WoMakersCode.Biblioteca.Application.Models.AdicionarUsuario
{
    public class AdicionarUsuarioResponse
    {
    }
}
