﻿namespace WoMakersCode.Biblioteca.Application.Models.ListarLivros
{
    public class ListarLivrosRequest
    {
    }
}
