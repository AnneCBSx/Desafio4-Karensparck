﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoMakersCode.Biblioteca.Application.Models.AdicionarEmprestimo
{
    public class AdicionarEmprestimoResponse
    {
    }
}
