﻿namespace WoMakersCode.Biblioteca.Application.Models.AdicionarAutor
{
    public class AdicionarAutorRequest
    {
        public string Nome { get; set; }
    }
}
