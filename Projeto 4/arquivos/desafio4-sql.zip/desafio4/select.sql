select * from livros;
select * from autores;
select * from emprestimos;
select * from usuarios;
